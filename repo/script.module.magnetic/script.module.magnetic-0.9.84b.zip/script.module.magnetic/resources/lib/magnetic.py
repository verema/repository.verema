# coding: utf-8
# Name:        magnetic.py
# Author:      Mancuniancol
# Created on:  28.11.2016
# Licence:     GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
Magnetic module which manages the providers and requests
"""

import urlparse
from threading import Thread
from urllib import quote_plus, unquote_plus

import filtering
from browser import read_torrent, get_cloudhole_key, get_cloudhole_clearance
from storage import *
from utils import *

provider_results = []
provider_name = []
available_providers = 0
request_time = time.clock()


def process_torrent(self):
    """
    Process the torrent information from a webpage
    :param self: request
    :type self: ProvidersHandler
    """
    # request data
    parsed = urlparse.urlparse(self.path)
    info = urlparse.parse_qs(parsed.query)
    uri = info.get('uri', [''])[0]
    filename = str(uuid.uuid4()) + '.torrent'

    # headers
    self.send_response(200)
    self.send_header('Content-type', 'application/x-bittorrent')
    self.send_header('Content-Disposition', 'attachment; filename="%s"' % filename)
    self.send_header('Content-Transfer-Encoding', 'binary')
    self.send_header('Accept-Ranges', 'bytes')
    self.end_headers()

    # torrent
    self.wfile.write(read_torrent(unquote_plus(uri)))


def process_provider(self):
    """
    Provider call back with results
    :param self: request
    :type self: ProvidersHandler
    """
    global provider_results
    global available_providers
    global provider_name

    # parsing path
    parsed = urlparse.urlparse(self.path)
    addonid = urlparse.parse_qs(parsed.query)['addonid'][0]
    content_length = int(self.headers['Content-Length'])
    payload = self.rfile.read(content_length)
    data = json.loads(payload)
    logger.info("Provider " + addonid + " returned " + str(len(data)) + " results in " + str(
        "%.1f" % round(time.clock() - request_time, 2)) + " seconds")
    provider_results.extend(data)
    available_providers -= 1
    if addonid in provider_name:
        provider_name.remove(addonid)

    # headers
    self.send_response(200)
    self.send_header('Content-type', 'text/html')
    self.end_headers()
    # send ok
    self.wfile.write("OK")


def get_results(self):
    """
    Process to get the results
    :param self: request
    :type self: ProvidersHandler
    """
    global provider_results

    # init list
    provider_results = []

    # request data
    parsed = urlparse.urlparse(self.path)
    info = urlparse.parse_qs(parsed.query)
    operation = info.get('search', [''])[0]
    provider = info.get('provider', [''])[0]
    title = unquote_plus(str(info.get('title', [''])[0]).replace("'", ""))
    imdb_id = info.get('imdb_id', [''])[0]
    if len(imdb_id) < 5:
        imdb_id = find_imdb(title)
    if operation == 'general':
        method = 'search'
        general_item = {'imdb_id': str(imdb_id),
                        'title': title}
        payload = json.dumps(general_item)

    elif operation == "movie":
        method = "search_movie"
        year = info.get('year', [''])[0]
        movie_item = {'imdb_id': str(imdb_id),
                      'title': title,
                      'year': str(year)}
        payload = json.dumps(movie_item)

    elif operation == "episode":
        method = "search_episode"
        season = info.get('season', [''])[0]
        episode = info.get('episode', [''])[0]
        episode_item = {'imdb_id': str(imdb_id),
                        'title': title,
                        'season': int(season),
                        'episode': int(episode),
                        'absolute_number': int(0)}
        payload = json.dumps(episode_item)

    elif operation == "season":
        method = "search_season"
        season = info.get('season', [''])[0]
        season_item = {'imdb_id': str(imdb_id),
                       'title': title,
                       'season': int(season),
                       'absolute_number': int(0)}
        payload = json.dumps(season_item)

    else:
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        # send the results
        self.wfile.write("OPERATION NOT FOUND")
        return

    if len(title) == 0 or len(method) == 0:
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        # send the results
        self.wfile.write("Payload Incomplete!!!      " + repr(payload))
        return

    # check if the search is in cache
    database = Storage.open("providers", 60 * 6, True)
    cache = database.get(payload, None)
    if cache is None or len(provider) > 0:
        # read the cloudhole key from the API
        if get_setting("use_cloudhole", bool):
            clearance, user_agent = get_cloudhole_clearance(get_cloudhole_key())
            set_setting('clearance', clearance)
            set_setting('user_agent', user_agent)

        # requests the results
        normalized_list = search(method, payload, provider)
        results = normalized_list
        # if there is results it will be saved in cache
        if len(normalized_list.get('magnets', [])) > 0:
            database[payload] = results
            database.sync()
    else:
        normalized_list = cache
        display_message_cache()

    logger.info("Filtering returned: " + str(len(normalized_list.get('magnets', []))) + " results")

    # headers
    self.send_response(200)
    self.send_header('Content-type', 'application/json')
    self.end_headers()
    # send the results
    self.wfile.write(json.dumps(normalized_list))


def search(method, payload_json, provider=""):
    """
    Search for torrents - call providers
    :param method: method of search
    :type method: str
    :param payload_json: parload in json format
    :type payload_json: str
    :param provider: name of provider, if the search is individually
    :type provider: str
    :return list of results
    """
    global provider_results
    global available_providers
    global request_time
    global provider_name

    # reset global variables
    provider_results = []
    provider_name = []
    available_providers = 0
    request_time = time.clock()
    # collect data
    if len(provider) == 0:
        addons = get_list_providers_enabled()
    else:
        addons = [provider]

    if len(addons) == 0:
        # return empty list
        notify(string(32060), image=get_icon_path())
        logger.info("No providers installed")
        return {'results': 0, 'duration': "0 seconds", 'magnets': []}

    p_dialog = xbmcgui.DialogProgressBG()
    p_dialog.create('Magnetic Manager', string(32061))
    for addon in addons:
        available_providers += 1
        provider_name.append(addon)
        task = Thread(target=run_provider, args=(addon, method, payload_json))
        task.start()

    providers_time = time.clock()
    total = float(available_providers)
    # while all providers have not returned results or timeout not reached
    time_out = min(get_setting("timeout", int), 60)
    # if all providers have returned results exit
    # check every 100ms
    while time.clock() - providers_time < time_out and available_providers > 0:
        xbmc.sleep(100)
        message = string(32062) % available_providers if available_providers > 1 else string(32063)
        p_dialog.update(int((total - available_providers) / total * 100), message=message)

    # time-out provider
    if len(provider_name) > 0:
        message = ', '.join(provider_name)
        message = message.replace('script.magnetic.', '').title() + string(32064)
        logger.info(message)
        notify(message, ADDON_ICON)

    # filter magnets and append to results
    filtered_results = dict(magnets=filtering.apply_filters(provider_results))
    # append number and time on payload
    filtered_results['results'] = len(filtered_results['magnets'])
    filtered_results['duration'] = str("%.1f" % round(time.clock() - request_time, 2)) + " seconds"
    logger.info(
        "Providers search returned: %s results in %s" % (str(len(provider_results)), filtered_results['duration']))
    # destroy notification object
    p_dialog.close()
    del p_dialog

    return filtered_results


def run_provider(addon, method, search_query):
    """
    Run external script
    :param addon: add-on to run
    :type addon: str
    :param method: method in the script
    :type method: str
    :param search_query: search or query
    :type search_query: str
    """
    logger.debug("Processing:" + addon)
    xbmc.executebuiltin(
        "RunScript(" + addon + "," + addon + "," + method + "," + quote_plus(search_query.encode('utf-8')) + ")", True)
