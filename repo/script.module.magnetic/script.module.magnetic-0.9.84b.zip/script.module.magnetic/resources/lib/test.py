# coding: utf-8
html = """
 <html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>The Tudors</title>
    <meta http-equiv="refresh" content="0;URL='http://thetudors.example.com/'" />
  </head>
  <body>
    <p>This page has moved to a <a href="http://thetudors.example.com/">
      theTudors.example.com</a>.</p>
  </body>
</html>
"""

import re

def find_refresh_url(html):
    """
    Find the url if there is refresh
    :param html:
    :return:
    """
    result = None
    if html.find('http-equiv="refresh"'):
        value = re.search('url=[\'\"](.*?)[\'\"]', html, re.IGNORECASE)
        if value:
            result = value.group(1)

        return result

print find_refresh_url(html)
