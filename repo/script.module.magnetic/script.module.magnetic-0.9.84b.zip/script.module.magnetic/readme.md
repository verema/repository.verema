EXAMPLES
--------
general: http://localhost:5005?search=general&title=ANYTHING
Movie: http://localhost:5005?search=movie&imdb=tt1111111&title=MOVIE&year=2016
Episode: http://localhost:5005?search=episode&title=SHOW&season=1&episode=1
Season: http://localhost:5005?search=season&title=SHOW&season=1


specific provider
general: http://localhost:5005?search=general&title=ANYTHING&provider=script.magnetic.name_provider



Installation
============
Please, visit this link: https://github.com/mancuniancol/repository.magnetic
