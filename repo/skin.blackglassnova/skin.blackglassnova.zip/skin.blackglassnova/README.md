## Black Glass Nova skin for Kodi 17 KRYPTON
Black Glass Nova is an easy to use and fanart oriented skin designed for Full HD TV screens.

![](http://i.imgur.com/bNT9T4C.jpg)

![](http://i.imgur.com/NxPPyDE.jpg)

#### Some pictures of the skin:
- [Black Glass Nova Mode](https://github.com/Tgxcorporation/skin.blackglassnova/wiki/Screenshots-BGN)
- [Black Glass Mode](https://github.com/Tgxcorporation/skin.blackglassnova/wiki/Screenshots-BG)

#### [Wiki](https://github.com/Tgxcorporation/skin.blackglassnova/wiki)

#### [Changelog](https://github.com/Tgxcorporation/skin.blackglassnova/blob/master/changelog.txt)

#### [Download from GitHub](https://github.com/Tgxcorporation/skin.blackglassnova/wiki/Install-from-GitHub)

#### Thanks
All the Kodi/XBMC team and addon developers.

#### Donations
If you liked this skin and you want to help a little bit, you can donate here:

[![PayPal Donate](https://www.paypal.com/en_US/i/btn/x-click-but04.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=BQTJSRCZ8GWHY&lc=US&item_name=Skins%20by%20Tgx%20for%20Kodi%20Entertainment%20Center&item_number=Kodi&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted)
